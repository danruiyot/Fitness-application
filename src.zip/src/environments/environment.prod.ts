export const environment = {
  production: true,
  firebaseConfig: {
	apiKey: "AIzaSyDHLHA2fQvPIyoOu8TTm_akQt4q1tnOq4g",
	authDomain: "kaafiti-65366.firebaseapp.com",
	databaseURL: "https://kaafiti-65366.firebaseio.com",
	projectId: "kaafiti-65366",
	storageBucket: "kaafiti-65366.appspot.com",
	messagingSenderId: "109044601520",
	appId: "1:109044601520:web:aca9a893c7db67d253a175",
	measurementId: "G-B95NMVDSZX"
  }
};
