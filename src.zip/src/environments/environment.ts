// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
	  apiKey: "AIzaSyDHLHA2fQvPIyoOu8TTm_akQt4q1tnOq4g",
	  authDomain: "kaafiti-65366.firebaseapp.com",
	  databaseURL: "https://kaafiti-65366.firebaseio.com",
	  projectId: "kaafiti-65366",
	  storageBucket: "kaafiti-65366.appspot.com",
	  messagingSenderId: "109044601520",
	  appId: "1:109044601520:web:aca9a893c7db67d253a175",
	  measurementId: "G-B95NMVDSZX"
	}

};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
