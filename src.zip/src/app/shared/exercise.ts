export class Exercise {
    $key: string;
    exercise_type: string;
    target_category: string;
    description: string;
    video_link: string;
}