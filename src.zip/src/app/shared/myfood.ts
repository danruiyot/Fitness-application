export class Myfood {
    $key: string;
    food_type: string;
    kcal_per_unit: number;
    protein: number;
    carbohydrates: number;
    fat: number;
    userId:string;
}