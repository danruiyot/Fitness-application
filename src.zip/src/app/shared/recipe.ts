export class Recipe {
    $key: string;
    food_type: string;
    recipe: string;
    kcal_per_unit: number;
    prep_time: number;
}