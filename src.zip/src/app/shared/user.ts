export class User {
    uid: string;
    email: string;
    displayName: string;
    photoURL: number;
    emailVerified: boolean;
}